<?php
$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; 
$password = '';
$db = new PDO($dsn, $username, $password);

if (!isset($_GET['gym_id'])) {
    // Rediriger vers une page d'erreur si aucun ID de salle de sport n'est spécifié
    header('Location: error.php');
    exit();
}

$gym_id = $_GET['gym_id'];

// Récupérer les informations de la salle de sport
$stmt = $db->prepare("SELECT * FROM gyms WHERE id = ?");
$stmt->execute([$gym_id]);
$gym = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$gym) {
    // Rediriger vers une page d'erreur si aucune salle de sport correspondant à cet ID n'est trouvée
    header('Location: error.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Profile</title>
</head>
<body>
    <h1>Gym Profile</h1>
    <h2><?php echo $gym['name']; ?></h2>
    <p>Description: <?php echo $gym['description']; ?></p>
    <p>Rules: <?php echo $gym['rules']; ?></p>
    <p>Schedule: <?php echo $gym['schedule']; ?></p>
    <p>Responsible Contact: <?php echo $gym['responsible_contact']; ?></p>
    <p>Type: <?php echo $gym['type']; ?></p>
    <!-- Ajoutez ici d'autres informations spécifiques à la salle de sport -->
</body>
</html>
