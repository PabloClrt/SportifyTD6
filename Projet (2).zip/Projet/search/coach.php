<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: /Projet/users/login.php');
    exit();
}

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; 
$password = '';
$db = new PDO($dsn, $username, $password);

if (isset($_GET['coach_id'])) {
    $coach_id = $_GET['coach_id'];

    // Fetch coach information
    $stmt = $db->prepare("
        SELECT c.*, u.first_name, u.last_name, u.email, u.address, u.student_card, u.phone
        FROM coaches c
        JOIN users u ON c.user_id = u.user_id
        WHERE c.coach_id = ?
    ");
    $stmt->execute([$coach_id]);
    $coach = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($coach) {
        // Parse the XML CV file if exists
        if ($coach['cv'] && file_exists("../" . $coach['cv'])) {
            $xml = simplexml_load_file("../" . $coach['cv']);
        } else {
            $xml = null;
        }
    } else {
        echo "Coach not found.";
        exit();
    }
} else {
    echo "No coach ID specified.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Coach Profile</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/Projet/sport.css">
</head>

  <header class="header">
  
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="/Projet/logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

	
    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="/Projet/search/search.php">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
</header>



<body>
    <div class="welcome-text">
        <h1>Coach Profile</h1>
        
        <h2>Personal Information</h2>
        <ul>
            <li>First Name: <?php echo htmlspecialchars($coach['first_name']); ?></li>
            <li>Last Name: <?php echo htmlspecialchars($coach['last_name']); ?></li>
            <li>Email: <?php echo htmlspecialchars($coach['email']); ?></li>
            <li>Address: <?php echo htmlspecialchars($coach['address']); ?></li>
            <li>Student Card: <?php echo htmlspecialchars($coach['student_card']); ?></li>
            <li>Phone: <?php echo htmlspecialchars($coach['phone']); ?></li>
        </ul>
        
        <h2>Coach Information</h2>
        <ul>
            <li>Specialty: <?php echo htmlspecialchars($coach['specialty']); ?></li>
            <li>Office: <?php echo htmlspecialchars($coach['office']); ?></li>
            <li>Bio: <?php echo htmlspecialchars($coach['bio']); ?></li>
            <li>Available Days: <?php echo htmlspecialchars($coach['available_days']); ?></li>
            <?php if ($coach['photo']): ?>
                <li><img src="<?php echo htmlspecialchars($coach['photo']); ?>" alt="Coach Photo"></li>
            <?php endif; ?>
        </ul>

        <?php if ($xml): ?>
        <button onclick="document.getElementById('cv').style.display == 'block' ? document.getElementById('cv').style.display = 'none' : document.getElementById('cv').style.display ='block'" class="small-button">Voir le CV</button><br>
        <div id="cv" style="display: none">

            <h2>CV</h2>
            <h3>Personal Information</h3>
            <ul>
                <li>Name: <?php echo htmlspecialchars($xml->personal_info->name); ?></li>
                <li>Age: <?php echo htmlspecialchars($xml->personal_info->age); ?></li>
                <li>Email: <?php echo htmlspecialchars($xml->personal_info->email); ?></li>
                <li>Contact: <?php echo htmlspecialchars($xml->personal_info->contact); ?></li>
            </ul>

            <h3>Education</h3>
            <ul>
                <li>Degree: <?php echo htmlspecialchars($xml->education->degree); ?></li>
                <li>Institution: <?php echo htmlspecialchars($xml->education->institution); ?></li>
                <li>Year: <?php echo htmlspecialchars($xml->education->year); ?></li>
            </ul>

            <h3>Experience</h3>
            <ul>
                <li>Job Title: <?php echo htmlspecialchars($xml->experience->job_title); ?></li>
                <li>Company: <?php echo htmlspecialchars($xml->experience->company); ?></li>
                <li>Duration: <?php echo htmlspecialchars($xml->experience->duration); ?></li>
            </ul>
			
        <?php else: ?>
            <p>No CV available.</p>
        <?php endif; ?>
        </div>

        <a href="/Projet/chatroom/chatroom.php?user_id=<?php echo $user['user_id']?>" class="small-button">Chat avec le coach</a>
    </div>
</body>




 <footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>

