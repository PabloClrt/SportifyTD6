<?php
session_start();

// if (!isset($_SESSION['user_id'])) {
//     header('Location: login.php');
//     exit();
// }

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; // Modifier avec votre nom d'utilisateur MySQL
$password = ''; // Modifier avec votre mot de passe MySQL
$db = new PDO($dsn, $username, $password);

$query = isset($_GET['query']) ? $_GET['query'] : '';

$searchSoundex = soundex($query);
$searchLike = '%' . $query . '%';

// Recherche de coaches
$stmt = $db->prepare("
    SELECT c.coach_id, CONCAT(u.first_name, ' ', u.last_name) AS coach_name, c.specialty, c.photo, c.bio
    FROM coaches c
    JOIN users u ON c.user_id = u.user_id
    WHERE SOUNDEX(CONCAT(u.first_name, ' ', u.last_name)) = ? 
    OR SOUNDEX(u.first_name) = ? 
    OR SOUNDEX(u.last_name) = ? 
    OR SOUNDEX(c.specialty) = ? 
    OR SOUNDEX(c.bio) = ?
    OR CONCAT(u.first_name, ' ', u.last_name) LIKE ?
    OR u.first_name LIKE ?
    OR u.last_name LIKE ?
    OR c.specialty LIKE ?
    OR c.bio LIKE ?
    LIMIT 10
");
$stmt->execute([$searchSoundex, $searchSoundex, $searchSoundex, $searchSoundex, $searchSoundex, $searchLike, $searchLike, $searchLike, $searchLike, $searchLike]);
$coaches = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Recherche de salles de sport
$stmt = $db->prepare("
    SELECT id, name, type
    FROM gyms
    WHERE SOUNDEX(name) = ? 
    OR SOUNDEX(type) = ?
    OR name LIKE ?
    OR type LIKE ?
    LIMIT 10
");
$stmt->execute([$searchSoundex, $searchSoundex, $searchLike, $searchLike]);
$gyms = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="/Projet/sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

	
    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
</header>

<body>

    <div class="search-container">
        <h1>Recherche</h1>
        <form action="" method="get">
            <input type="text" name="query" placeholder="Rechercher...">
            <button type="submit">Rechercher</button>
        </form>

        <h1>Résultats de recherche :</h1>

        <h2>Coaches</h2>
        <?php if (count($coaches) > 0): ?>
            <ul>
                <?php foreach ($coaches as $coach): ?>
                    <li>
                        <a href="coach.php?coach_id=<?php echo $coach['coach_id']; ?>">
                            <?php echo htmlspecialchars($coach['coach_name']); ?> - <?php echo htmlspecialchars($coach['specialty']); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Aucun coach trouvé.</p>
        <?php endif; ?>

        <h2>Salles de sport</h2>
        <?php if (count($gyms) > 0): ?>
            <ul>
                <?php foreach ($gyms as $gym): ?>
                    <li>
                        <a href="gym.php?gym_id=<?php echo $gym['id']; ?>">
                            <?php echo htmlspecialchars($gym['name']); ?> - <?php echo htmlspecialchars($gym['type']); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Aucune salle de sport trouvée.</p>
        <?php endif; ?>
    </div>
</body>

<footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>