<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /Sportify/users/login.php');
    exit();
}

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; 
$password = '';
$db = new PDO($dsn, $username, $password);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gym_id'])) {
    $gym_id = $_POST['gym_id'];

    // Supprimez les informations de la salle de sport de la table gyms
    $stmt = $db->prepare("DELETE FROM gyms WHERE id = ?");
    $stmt->execute([$gym_id]);

    // Optionnel : Vous pouvez aussi supprimer ou mettre à jour d'autres informations liées à cette salle de sport dans d'autres tables si nécessaire.

    // Redirigez vers la page d'administration après suppression
    header('Location: admin.php');
    exit();
} 
?>
<!DOCTYPE html>
<html>

<head>  <title>Supprimer Salle de Sport</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/Projet/sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
	
</header>

<body>
    <div class="welcome-text">
        <h1>Suppression d'une Salle de Sport</h1>
        <form action="delete_gym.php" method="POST">
            <input type="hidden" name="gym_id" value="<?php echo $_GET['gym_id']; ?>">
            <p>Êtes-vous sûr de vouloir supprimer cette salle de sport?</p>
            <button type="submit">Oui, supprimer</button>
            <a href="admin.php">Annuler</a>
        </form>
    </div>
</body>


 <footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>
