<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /Sportify/users/login.php');
    exit();
}

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; 
$password = '';
$db = new PDO($dsn, $username, $password);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gym_id'])) {
    $gym_id = $_POST['gym_id'];
    // Récupérer les nouvelles données du formulaire
    $name = $_POST['name'];
    $description = $_POST['description'];
    $rules = $_POST['rules']; // Ajout du champ rules
    $type = $_POST['type']; // Ajout du champ type
    $schedule = $_POST['schedule']; // Ajout du champ schedule
    $responsible_contact = $_POST['responsible_contact']; // Ajout du champ responsible_contact
    // Mettre à jour les informations de la salle de sport dans la base de données
    $stmt = $db->prepare("UPDATE gyms SET name = ?, description = ?, rules = ?, type = ?, schedule = ?, responsible_contact = ? WHERE id = ?");
    $stmt->execute([$name, $description, $rules, $type, $schedule, $responsible_contact, $gym_id]);
    // Rediriger vers la page d'administration après la modification
    header('Location: admin.php');
    exit();
} elseif (isset($_GET['gym_id'])) {
    // Récupérer les informations actuelles de la salle de sport à modifier
    $gym_id = $_GET['gym_id'];
    $stmt = $db->prepare("SELECT name, description, rules, type, schedule, responsible_contact FROM gyms WHERE id = ?");
    $stmt->execute([$gym_id]);
    $gym = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    // Si gym_id n'est pas défini, rediriger vers la page d'administration
    header('Location: admin.php');
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>  <title>Modifier Salle de Sport</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/Projet/sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
	
</header>

<body>
    <div class="welcome-text">
        <h1>Modifier Salle de Sport</h1>
        <form action="edit_gym.php" method="POST">
            <input type="hidden" name="gym_id" value="<?php echo $gym_id; ?>">
            <label for="name">Nom:</label>
            <input type="text" id="name" name="name" value="<?php echo $gym['name']; ?>" required><br>
            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo $gym['description']; ?></textarea><br>
            <label for="rules">Règles:</label>
            <textarea id="rules" name="rules" required><?php echo $gym['rules']; ?></textarea><br>
            <label for="type">Type:</label>
            <input type="text" id="type" name="type" value="<?php echo $gym['type']; ?>" required><br>
            <label for="schedule">Horaires:</label>
            <textarea id="schedule" name="schedule" required><?php echo $gym['schedule']; ?></textarea><br>
            <label for="responsible_contact">Contact du responsable:</label>
            <input type="text" id="responsible_contact" name="responsible_contact" value="<?php echo $gym['responsible_contact']; ?>" required><br>
            <button type="submit">Enregistrer</button>
            <a href="admin.php">Annuler</a>
        </form>
    </div>
</body>


 <footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>
