<?php
session_start();

// Vérifiez que l'utilisateur est un administrateur
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; // Modifier avec votre nom d'utilisateur MySQL
$password = ''; // Modifier avec votre mot de passe MySQL
$db = new PDO($dsn, $username, $password);
?>

<!DOCTYPE html>
<html>

<head>  <title>Create Coach</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/Projet/sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
</header>


<body>
    <div class="welcome-text">
        <h1>Create Coach</h1>

        <div class="search-container">
            <h2>Search for User</h2>
            <form method="GET" action="create_coach.php">
                <label for="search">Search by Name:</label>
                <input type="text" id="search" name="search" required>
                <button type="submit">Search</button>
            </form>

            <?php
            if (isset($_GET['search'])) {
                $search = $_GET['search'];
                $stmt = $db->prepare("SELECT user_id, CONCAT(first_name, ' ', last_name) AS name FROM users WHERE role = 'client' AND (first_name LIKE ? OR last_name LIKE ?)");
                $stmt->execute(['%' . $search . '%', '%' . $search . '%']);
                $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($users) {
                    echo "<h2>Search Results</h2>";
                    echo "<ul>";
                    foreach ($users as $user) {
                        echo "<li><a href=\"create_coach.php?user_id={$user['user_id']}\">{$user['name']}</a></li>";
                    }
                    echo "</ul>";
                } else {
                    echo "<p>No users found.</p>";
                }
            }
            ?>
        </div>

        <?php
        if (isset($_GET['user_id'])) {
            $user_id = $_GET['user_id'];
            $stmt = $db->prepare("SELECT user_id, CONCAT(first_name, ' ', last_name) AS name FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
        ?>

        <h2>Create Coach for <?php echo htmlspecialchars($user['name']); ?></h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">

            <label for="specialty">Specialty:</label>
            <input type="text" id="specialty" name="specialty" required><br>

            <label for="photo">Photo:</label>
            <input type="file" id="photo" name="photo"><br>

            <label for="bio">Bio:</label>
            <textarea id="bio" name="bio" required></textarea><br>

            <label for="available_days">Available Days:</label>
            <input type="text" id="available_days" name="available_days" required><br>

            <label for="office">Office:</label>
            <input type="text" id="office" name="office"><br>

            <label for="cv">CV:</label>
            <input type="file" id="cv" name="cv"><br>

            <button type="submit">Create Coach</button>
        </form>

        <?php
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user_id = $_POST['user_id'];
            $specialty = $_POST['specialty'];
            $photo = $_FILES['photo'];
            $bio = $_POST['bio'];
            $available_days = $_POST['available_days'];
            $office = $_POST['office'];
            $cv = $_FILES['cv'];

            // Validate available_days as JSON
            if (!json_decode($available_days)) {
                echo "Available days must be a valid JSON string.";
                exit();
            }

            // Handle file upload for photo
            $photoPath = null;
            if ($photo['error'] == UPLOAD_ERR_OK) {
                $photoDirectory = __DIR__ . '../uploads/';
                if (!is_dir($photoDirectory)) {
                    mkdir($photoDirectory, 0777, true);
                }
                $photoPath = $photoDirectory . basename($photo['name']);
                move_uploaded_file($photo['tmp_name'], $photoPath);
                $photoPath = '../uploads/' . basename($photo['name']);
            }

            // Handle file upload for CV
            $cvPath = null;
            if ($cv['error'] == UPLOAD_ERR_OK) {
                $cvDirectory = __DIR__ . '../uploads/cv/';
                if (!is_dir($cvDirectory)) {
                    mkdir($cvDirectory, 0777, true);
                }
                $cvPath = $cvDirectory . basename($cv['name']);
                move_uploaded_file($cv['tmp_name'], $cvPath);
                $cvPath = '../uploads/cv/' . basename($cv['name']);
            }

            // Update the user role to coach
            $stmt = $db->prepare("UPDATE users SET role = 'coach' WHERE user_id = ?");
            $stmt->execute([$user_id]);

            // Insert the new coach information
            $stmt = $db->prepare("INSERT INTO coaches (user_id, specialty, photo, bio, available_days, office, cv) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $specialty, $photoPath, $bio, $available_days, $office, $cvPath]);

            echo "Le coach a été créé avec succès!";
        }
        ?>
    </div>
</body>

 <footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>
