<?php
session_start();

// Vérifiez que l'utilisateur est un administrateur
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; // Modifier avec votre nom d'utilisateur MySQL
$password = ''; // Modifier avec votre mot de passe MySQL
$db = new PDO($dsn, $username, $password);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $rules = $_POST['rules'];
    $schedule = $_POST['schedule'];
    $responsible_contact = $_POST['responsible_contact'];
    $type = $_POST['type'];

    $stmt = $db->prepare("INSERT INTO gyms (name, description, rules, schedule, responsible_contact, type) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $description, $rules, $schedule, $responsible_contact, $type]);

    echo "La salle de sport a été créée avec succès!";
}
?>

<!DOCTYPE html>
<html>

<head>  <title>Create Gym</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/Projet/sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
	
</header>


<body>
    <div class="welcome-text">
        <h1>Create Gym</h1>
        <form method="POST">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea><br>

            <label for="rules">Rules:</label>
            <textarea id="rules" name="rules" required></textarea><br>

            <label for="schedule">Schedule:</label>
            <textarea id="schedule" name="schedule" required></textarea><br>

            <label for="responsible_contact">Responsible Contact:</label>
            <input type="text" id="responsible_contact" name="responsible_contact" required><br>

            <label for="type">Type:</label>
            <select id="type" name="type" required>
                <option value="activité sportive">Activité Sportive</option>
                <option value="sport de compétition">Sport de Compétition</option>
                <option value="salle de sport Omnes">Salle de Sport Omnes</option>
            </select><br>

            <button type="submit">Create Gym</button>
        </form>
    </div>
</body>


 <footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>
