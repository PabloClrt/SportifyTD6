<?php
session_start();

// Vérifiez que l'utilisateur est un administrateur
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; // Modifier avec votre nom d'utilisateur MySQL
$password = ''; // Modifier avec votre mot de passe MySQL
$db = new PDO($dsn, $username, $password);

if (isset($_GET['coach_id'])) {
    $coach_id = $_GET['coach_id'];

    // Fetch coach information
    $stmt = $db->prepare("SELECT c.*, u.first_name, u.last_name, u.email, u.address, u.phone FROM coaches c JOIN users u ON c.user_id = u.user_id WHERE c.coach_id = ?");
    $stmt->execute([$coach_id]);
    $coach = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$coach) {
        echo "Coach not found.";
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $specialty = $_POST['specialty'];
        $bio = $_POST['bio'];
        $available_days = $_POST['available_days'];
        $office = $_POST['office'];
        $cv_path = $coach['cv'];

        // Handle photo upload
        if (!empty($_FILES['photo']['name'])) {
            $photo = $_FILES['photo'];
            $photo_path = '/uploads/' . basename($photo['name']);
            move_uploaded_file($photo['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . $photo_path);
        } else {
            $photo_path = $coach['photo'];
        }

        // Handle CV upload
        if (!empty($_FILES['cv']['name'])) {
            $cv = $_FILES['cv'];
            $cv_path = '/uploads/cv/' . basename($cv['name']);
            move_uploaded_file($cv['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . $cv_path);
        }

        // Update coach information
        $stmt = $db->prepare("
            UPDATE coaches
            SET specialty = ?, bio = ?, available_days = ?, office = ?, photo = ?, cv = ?
            WHERE coach_id = ?
        ");
        $stmt->execute([$specialty, $bio, $available_days, $office, $photo_path, $cv_path, $coach_id]);

        header("Location: /Sportify/search/coach.php?coach_id=$coach_id");
        exit();
    }
} else {
    echo "No coach ID specified.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>  <title>Modifier Coach</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/Projet/sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
	
</header>

<body>
    <div class="welcome-text">
        <h1>Edit Coach</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="specialty">Specialty:</label>
            <input type="text" name="specialty" id="specialty" value="<?php echo htmlspecialchars($coach['specialty']); ?>" required>
            <br>

            <label for="bio">Bio:</label>
            <textarea name="bio" id="bio" required><?php echo htmlspecialchars($coach['bio']); ?></textarea>
            <br>

            <label for="available_days">Available Days:</label>
            <textarea name="available_days" id="available_days" required><?php echo htmlspecialchars($coach['available_days']); ?></textarea>
            <br>

            <label for="office">Office:</label>
            <input type="text" name="office" id="office" value="<?php echo htmlspecialchars($coach['office']); ?>" required>
            <br>

            <label for="photo">Photo:</label>
            <input type="file" name="photo" id="photo" accept="image/*">
            <?php if ($coach['photo']): ?>
                <img src="<?php echo htmlspecialchars($coach['photo']); ?>" alt="Coach Photo" style="max-width: 100px;">
            <?php endif; ?>
            <br>

            <label for="cv">CV (XML):</label>
            <input type="file" name="cv" id="cv" accept=".xml">
            <br>
            
            <button type="submit">Update Coach</button>
        </form>

        <h2>Current User Information</h2>
        <div>
            <p>Name: <?php echo htmlspecialchars($coach['first_name'] . ' ' . $coach['last_name']); ?></p>
            <br>
            <p>Email: <?php echo htmlspecialchars($coach['email']); ?></p>
            <br>
            <p>Address: <?php echo htmlspecialchars($coach['address']); ?></p>
            <br>
            <p>Phone: <?php echo htmlspecialchars($coach['phone']); ?></p>
            <br>
        </div>
    </div>
</body>



 <footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>
