<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /Sportify/users/login.php');
    exit();
}

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; 
$password = '';
$db = new PDO($dsn, $username, $password);

// Recherche de tous les coaches
$stmt = $db->query("
    SELECT c.coach_id, CONCAT(u.first_name, ' ', u.last_name) AS coach_name, c.specialty AS specialty, u.email
    FROM coaches c
    JOIN users u ON c.user_id = u.user_id LIMIT 20
");
$coaches = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt2 = $db->query("SELECT id, name, type FROM gyms");
$gyms = $stmt2->fetchAll(PDO::FETCH_ASSOC);

if (isset($_GET['search'])) {
    $search = '%' . $_GET['search'] . '%';
    // Recherche d'un coach par nom, prénom ou email
    $stmt = $db->prepare("
        SELECT c.coach_id, CONCAT(u.first_name, ' ', u.last_name) AS coach_name, c.specialty AS specialty, u.email
        FROM coaches c
        JOIN users u ON c.user_id = u.user_id
        WHERE u.first_name LIKE ? 
        OR u.last_name LIKE ? 
        OR u.email LIKE ?
        OR c.specialty LIKE ? LIMIT 20
    ");

    $stmt->execute([$search, $search, $search, $search]);
    $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);


    // Recherche d'un gym par nom ou email
    $stmt = $db->prepare("
        SELECT id, name, type
        FROM gyms
        WHERE name LIKE ? 
        OR type LIKE ? LIMIT 20
    ");
    $stmt->execute([$search, $search]);
    $searchResultsGym = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>

<head>  <title>Administration</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/Projet/sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
</header>

<body>
    <div class="welcome-text">
        <h1>Administration</h1>
        <a href="create_coach.php">Créer un nouveau coach</a>
        <a href="create_gym.php">Créer une salle de sport</a>
        <form action="admin.php" method="GET">
            <input type="text" name="search" placeholder="Rechercher un coach...">
            <button type="submit">Rechercher</button>
            <button type="button" onclick="window.location.href='admin.php'">Effacer la recherche</button>
        </form>

        <h2>Liste des Coaches</h2>
        <ul>       
            <?php if (isset($searchResults)): ?>
                <?php foreach ($searchResults as $coach): ?>
                    <li>
                        <a href="coach_profile.php?id=<?php echo $coach['coach_id']; ?>">
                            <?php echo htmlspecialchars($coach['coach_name']); ?> - <?php echo htmlspecialchars($coach['email']); ?> - <?php echo htmlspecialchars($coach["specialty"]) ?>
                        </a>
                        <div class="actions" style="display: flex; flex-direction: row;">
                            <button class="small-button" onclick="window.location.href='edit_coach.php?coach_id=<?php echo $coach['coach_id']; ?>'">Modifier</button>
                            <button class="small-button delete-button" onclick="window.location.href='delete_coach.php?coach_id=<?php echo $coach['coach_id']; ?>'">Supprimer</button>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <?php foreach ($coaches as $coach): ?>
                    <li>
                        <a href="coach_profile.php?id=<?php echo $coach['coach_id']; ?>">
                            <?php echo htmlspecialchars($coach['coach_name']); ?> - <?php echo htmlspecialchars($coach['email']); ?> - <?php echo htmlspecialchars($coach["specialty"]) ?>
                        </a>
                        <div class="actions">
                            <button class="small-button" onclick="window.location.href='edit_coach.php?coach_id=<?php echo $coach['coach_id']; ?>'">Modifier</button>
                            <button class="small-button delete-button" onclick="window.location.href='delete_coach.php?coach_id=<?php echo $coach['coach_id']; ?>'">Supprimer</button>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>

        <h2>Liste des Gyms</h2>
        <ul>
            <?php if (isset($searchResultsGym) && !empty($searchResultsGym)): ?>
                <?php foreach ($searchResultsGym as $gym): ?>
                    <li>
                        <a href="gym_profile.php?gym_id=<?php echo $gym['id']; ?>">
                            <?php echo htmlspecialchars($gym['name']); ?> - <?php echo htmlspecialchars($gym['type']); ?>
                        </a>
                        <div class="actions">
                            <button class="small-button" onclick="window.location.href='edit_gym.php?gym_id=<?php echo $gym['id']; ?>'">Modifier</button>
                            <button class="small-button delete-button" onclick="window.location.href='delete_gym.php?gym_id=<?php echo $gym['id']; ?>'">Supprimer</button>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <?php foreach ($gyms as $gym): ?>
                    <li>
                        <a href="gym_profile.php?gym_id=<?php echo $gym['id']; ?>">
                            <?php echo htmlspecialchars($gym['name']); ?> - <?php echo htmlspecialchars($gym['type']); ?>
                        </a>
                        <div class="actions">
                            <button class="small-button" onclick="window.location.href='edit_gym.php?gym_id=<?php echo $gym['id']; ?>'">Modifier</button>
                            <button class="small-button delete-button" onclick="window.location.href='delete_gym.php?gym_id=<?php echo $gym['id']; ?>'">Supprimer</button>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>
    </div>
</body>





 <footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>