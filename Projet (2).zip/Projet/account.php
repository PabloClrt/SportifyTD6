<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'];

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; // Modifier avec votre nom d'utilisateur MySQL
$password = ''; // Modifier avec votre mot de passe MySQL
$db = new PDO($dsn, $username, $password);

// Récupérer les informations de l'utilisateur
$stmt = $db->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "Utilisateur non trouvé.";
    exit();
}

$coach = null;
if ($userRole === 'coach') {
    $stmt = $db->prepare("SELECT * FROM coaches WHERE user_id = ?");
    $stmt->execute([$userId]);
    $coach = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mon Compte</title>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

	
    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
</header>

<body>
    <div class="welcome-text">
        <h1>Mon Compte</h1>
        <form action="update_account.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['user_id']); ?>">
            <div>
                <label>Prénom:</label>
                <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>">
            </div>
            <div>
                <label>Nom:</label>
                <input type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>">
            </div>
            <div>
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
            </div>
            <div>
                <label>Adresse:</label>
                <input type="text" name="address" value="<?php echo htmlspecialchars($user['address']); ?>">
            </div>
            <div>
                <label>Téléphone:</label>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
            </div>
            <?php if ($userRole === 'coach' && $coach): ?>
                <div>
                    <label>Bio:</label>
                    <textarea name="bio"><?php echo htmlspecialchars($coach['bio']); ?></textarea>
                </div>
                <div>
                    <label>Photo:</label>
                    <input type="file" name="photo">
                    <?php if ($coach['photo']): ?>
                        <img src="<?php echo htmlspecialchars($coach['photo']); ?>" alt="Photo de profil" width="100">
                    <?php endif; ?>
                </div>
                <div>
                    <label>Jours Disponibles:</label>
                    <textarea name="available_days"><?php echo htmlspecialchars($coach['available_days']); ?></textarea>
                </div>
                <div>
                    <label>Bureau:</label>
                    <input type="text" name="office" value="<?php echo htmlspecialchars($coach['office']); ?>">
                </div>
                <div>
                    <label>CV:</label>
                    <input type="file" name="cv">
                    <?php if ($coach['cv']): ?>
                        <a href="<?php echo htmlspecialchars($coach['cv']); ?>">Voir le CV</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div>
                <button type="submit">Mettre à jour</button>
            </div>
        </form>

        <?php if ($userRole === 'admin'): ?>
            <a href="admin/admin.php">Page d'administration</a>
        <?php endif; ?>
        <a href="/Projet/chatroom/inbox.php">Vos messages</a>
        <a href="./logout.php">Se déconnecter</a>
    </div>
</body>


<footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>

</html>