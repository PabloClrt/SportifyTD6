<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_POST['user_id'];
$userRole = $_SESSION['role'];

$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; // Modifier avec votre nom d'utilisateur MySQL
$password = ''; // Modifier avec votre mot de passe MySQL
$db = new PDO($dsn, $username, $password);

$firstName = $_POST['first_name'];
$lastName = $_POST['last_name'];
$email = $_POST['email'];
$address = $_POST['address'];
$phone = $_POST['phone'];

// Mettre à jour les informations de base de l'utilisateur
$query = "
    UPDATE users 
    SET first_name = ?, last_name = ?, email = ?, address = ?, phone = ?
    WHERE user_id = ?
";
$params = [$firstName, $lastName, $email, $address, $phone, $userId];
$stmt = $db->prepare($query);
$stmt->execute($params);

// Si l'utilisateur est un coach, mettre à jour les informations spécifiques du coach
if ($userRole === 'coach') {
    $bio = $_POST['bio'];
    $availableDays = $_POST['available_days'];
    $office = $_POST['office'];
    $cv = null;

    // Gestion de la photo de profil
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == UPLOAD_ERR_OK) {
        $photo = 'uploads/' . $userId . '.jpg';
        move_uploaded_file($_FILES['photo']['tmp_name'], $photo);
    } else {
        $photo = $_POST['current_photo']; // Garder la photo actuelle si pas de nouvelle uploadée
    }

    // Gestion du CV
    if (isset($_FILES['cv']) && $_FILES['cv']['error'] == UPLOAD_ERR_OK) {
        $cv = 'uploads/cv/' . $userId . '.pdf';
        move_uploaded_file($_FILES['cv']['tmp_name'], $cv);
    } else {
        $cv = $_POST['current_cv']; // Garder le CV actuel si pas de nouveau uploadé
    }

    $query = "
        UPDATE coaches 
        SET bio = ?, available_days = ?, office = ?, photo = ?, cv = ?
        WHERE user_id = ?
    ";
    $params = [$bio, $availableDays, $office, $photo, $cv, $userId];
    $stmt = $db->prepare($query);
    $stmt->execute($params);
}

header('Location: ../account.php');
exit();
?>
