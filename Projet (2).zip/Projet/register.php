<?php
session_start();
$dsn = 'mysql:host=localhost;dbname=sportify';
$username = 'root'; 
$password = '';
$db = new PDO($dsn, $username, $password);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    // Vérifiez si l'email existe déjà
    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $emailExists = $stmt->fetchColumn();

    if ($emailExists) {
        $error = "Un utilisateur avec cet email existe déjà.";
    } else {
        // Enregistrer l'utilisateur sans la carte d'étudiant pour obtenir l'ID utilisateur
        $stmt = $db->prepare("INSERT INTO users (first_name, last_name, email, password, role, address, phone) VALUES (?, ?, ?, ?, 'client', ?, ?)");
        if ($stmt->execute([$firstName, $lastName, $email, $password, $address, $phone])) {
            $userId = $db->lastInsertId();

            // Handling the uploaded student card image
            $targetDir = "uploads/";
            $studentCard = $targetDir . $userId . "." . strtolower(pathinfo($_FILES["student_card"]["name"], PATHINFO_EXTENSION));
            $uploadOk = 1;

            // Check if image file is a actual image or fake image
            $check = getimagesize($_FILES["student_card"]["tmp_name"]);
            if ($check !== false) {
                $uploadOk = 1;
            } else {
                $uploadOk = 0;
                $error = "Le fichier n'est pas une image.";
            }

            // Check file size
            if ($_FILES["student_card"]["size"] > 500000) { // 500 KB
                $uploadOk = 0;
                $error = "Désolé, votre fichier est trop volumineux.";
            }

            // Allow certain file formats
            $imageFileType = strtolower(pathinfo($studentCard, PATHINFO_EXTENSION));
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $uploadOk = 0;
                $error = "Désolé, seuls les fichiers JPG, JPEG, PNG et GIF sont autorisés.";
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                $error = "Désolé, votre fichier n'a pas été téléchargé.";
            } else {
                if (move_uploaded_file($_FILES["student_card"]["tmp_name"], $studentCard)) {
                    // File is uploaded successfully, now update user data with the student card path
                    $stmt = $db->prepare("UPDATE users SET student_card = ? WHERE user_id = ?");
                    if ($stmt->execute([$studentCard, $userId])) {
                        header('Location: login.php');
                        exit();
                    } else {
                        $error = "Une erreur s'est produite lors de la mise à jour de l'enregistrement. Veuillez réessayer.";
                    }
                } else {
                    $error = "Désolé, une erreur s'est produite lors du téléchargement de votre fichier.";
                }
            }
        } else {
            $error = "Une erreur s'est produite lors de l'enregistrement. Veuillez réessayer.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;400;500;900&family=Poppins&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="sport.css">
</head>

<header class="header">
  
    <div class="title-container">
        <h1 class="title"><span class="highlight">Sportify : </span> Consultation Sportive</h1>
        <div class="logo-content">
            <img class="logo" src="logo2.png" alt="Logo Sportify">
        </div>
    </div>
	

	
    <nav class="header-nav container">
        <ul>
            <li><a href="/Projet/index.html">Accueil</a></li>
            <li><a href="#tout-parcourir">Tout Parcourir</a></li>
            <li><a href="search.php?query=...">Recherche</a></li>
            <li><a href="#rendez-vous">Rendez-vous</a></li>
            <li><a href="/Projet/account.php">Votre Compte</a></li>
        </ul>
    </nav>
</header>


<body>
    <div class="welcome-text">
        <h1>Register</h1>
        <?php if (isset($error)): ?>
            <p style="color:red;"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST" action="register.php" enctype="multipart/form-data">
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name" required><br>
            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name" required><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required><br>
            <label for="student_card">Student Card (Image):</label>
            <input type="file" id="student_card" name="student_card" accept="image/*" required><br>
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" required><br>
            <button type="submit">Register</button>
        </form>
    </div>
</body>



<footer class="footer">
    <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Email: <a href="mailto:contact@sportify.com" style="color: red;">contact.sportify@gmail.com</a></p>
        <p>Téléphone: <span style="color: red;">+33 123 456 789</span></p>
        <p>Adresse: <span style="color: red;">10 Rue Sextius Michel, 75015 Paris</span></p>
    </div>
    <div class="map">
        <!-- Intégration de la carte Google Maps -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5250.732219247867!2d2.285990976128141!3d48.85122870121092!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701b4f58251b%3A0x167f5a60fb94aa76!2sECE%20-%20Ecole%20d&#39;ing%C3%A9nieurs%20-%20Campus%20de%20Paris!5e0!3m2!1sfr!2sfr!4v1717059891597!5m2!1sfr!2sfr" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
		
</footer>
</html>